module ccprog3_mco {
    requires javafx.controls;
    exports ccprog3_mco;
}